package com.mycompany.a3;

//The Interface ISteerable.

public interface ISteerable {
	
	/**
	 * Turn left.
	 */
	public void turnLeft();
	
	/**
	 * Turn right.
	 */
	public void turnRight();

}
