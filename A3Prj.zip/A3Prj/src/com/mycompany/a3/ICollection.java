package com.mycompany.a3;

public interface ICollection {
	
	//adds an object to the list
	public void add(GameObject newObject);

	 // returns the iterator
	public IIterator getIterator();
	

	public void remove(GameObject newObjec);


	
	

}
